
local FILTER = {}

FILTER.Q = 2
FILTER.frequency = 16000
FILTER.type = "slider"
FILTER.min = -12
FILTER.max = 12
FILTER.value = 0

FILTER.descriptions = {
    Q = "Q factor",
    frequency = "Frequency (Hz)",
    minimum = "Min gain",
    max = "Max gain",
    value = "Gain"
}

--function FILTER:label()
FILTER.label = function(self) --can either be a function or a string
    if self.frequency >= 1000 then
        return tostring(self.frequency / 1000) .. "K"
    else
        return tostring(self.frequency)
    end
end

function FILTER:deq22_coefs(gain, sampling_rate)
    local omega = 2*math.pi*self.frequency/sampling_rate
    local omegaS = math.sin(omega)
    local omegaC = math.cos(omega)

    local alpha = omegaS / (2*self.Q);

    local A = math.sqrt(math.pow(10, gain/20));

    local a0 = 1 + alpha/A;
    return
        (1 + alpha*A) / a0, --b0
        (-2 * omegaC) / a0, --b1
        (1 - alpha*A) / a0, --b2
        (-2 * omegaC) / a0, --a1
        (1 - alpha/A) / a0  --a2
end

return FILTER
