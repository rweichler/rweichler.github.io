local pid=...

local f= "/tmp/lucypid/"..pid..".lua"
dofile(f)
